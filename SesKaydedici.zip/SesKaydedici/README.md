# Ses Kaydedici
Yüksek kaliteli, ham (işlenmemiş) WAV ses kaydedici. Android 14, Compose + Material 3.
