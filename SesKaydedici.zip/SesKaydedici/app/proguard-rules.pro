# Ek kural gerekmiyor.
