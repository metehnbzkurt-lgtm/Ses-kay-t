package com.oguzhn.seskaydedici

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.log10

class RecorderService : Service() {

    companion object {
        const val ACTION_START = "com.oguzhn.seskaydedici.START"
        const val ACTION_PAUSE = "com.oguzhn.seskaydedici.PAUSE"
        const val ACTION_RESUME = "com.oguzhn.seskaydedici.RESUME"
        const val ACTION_STOP = "com.oguzhn.seskaydedici.STOP"
        private const val CHANNEL = "rec"
        private const val NOTIF_ID = 1
        const val RATE = 48000
    }

    private class Opened(val ar: AudioRecord, val bytesPerSample: Int, val sourceName: String)

    @Volatile private var running = false
    @Volatile private var paused = false
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel(CHANNEL, "Kayıt", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start()
            ACTION_PAUSE -> setPaused(true)
            ACTION_RESUME -> setPaused(false)
            ACTION_STOP -> stopRecording()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    // ---------- bildirim ----------
    private fun buildNotif(title: String, recording: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        fun act(a: String, req: Int) = PendingIntent.getService(
            this, req, Intent(this, RecorderService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_mic)
            .setContentTitle(title)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
        if (recording) {
            b.setUsesChronometer(true)
                .setWhen(System.currentTimeMillis() - RecorderState.elapsedMs.value)
            b.addAction(0, "Duraklat", act(ACTION_PAUSE, 1))
        } else {
            b.setShowWhen(false)
            b.addAction(0, "Devam", act(ACTION_RESUME, 2))
        }
        b.addAction(0, "Bitir", act(ACTION_STOP, 3))
        return b.build()
    }

    private fun goForeground(title: String, recording: Boolean) {
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotif(title, recording),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        )
    }

    private fun updateNotif(title: String, recording: Boolean) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID, buildNotif(title, recording))
    }

    // ---------- kontrol ----------
    private fun start() {
        runCatching { goForeground("Kayıt yapılıyor", true) }.onFailure {
            RecorderState.error.value = "Kayıt başlatılamadı: ${it.message}"
            stopSelf()
            return
        }
        if (running) return

        val sp = getSharedPreferences("settings", MODE_PRIVATE)
        val channels = sp.getInt("channels", 1)
        val bits = sp.getInt("bits", 16)
        val raw = sp.getInt("source", 0) == 0
        val export = sp.getBoolean("export", true)

        running = true
        paused = false
        RecorderState.elapsedMs.value = 0L
        RecorderState.levels.value = emptyList()
        RecorderState.clip.value = false
        RecorderState.status.value = Status.RECORDING

        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "seskaydedici:rec")
            .apply { acquire(6 * 60 * 60 * 1000L) }

        Thread({ record(channels, bits, raw, export) }, "recorder").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    private fun setPaused(p: Boolean) {
        if (!running) return
        paused = p
        RecorderState.status.value = if (p) Status.PAUSED else Status.RECORDING
        if (p) {
            RecorderState.levels.value = emptyList()
            RecorderState.clip.value = false
        }
        updateNotif(if (p) "Duraklatıldı" else "Kayıt yapılıyor", !p)
    }

    private fun stopRecording() {
        if (running) {
            running = false
        } else {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    // ---------- ses kaynağı ----------
    private fun open(channels: Int, bits: Int, raw: Boolean): Opened? {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val unprocessed = am.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) == "true"

        val sources = ArrayList<Pair<Int, String>>()
        if (raw) {
            if (unprocessed) sources.add(Pair(MediaRecorder.AudioSource.UNPROCESSED, "Ham"))
            sources.add(Pair(MediaRecorder.AudioSource.VOICE_RECOGNITION, "Düşük işlemli"))
        }
        sources.add(Pair(MediaRecorder.AudioSource.MIC, "Standart mikrofon"))

        val mask = if (channels == 2) AudioFormat.CHANNEL_IN_STEREO else AudioFormat.CHANNEL_IN_MONO
        val encs = if (bits == 24 && Build.VERSION.SDK_INT >= 31)
            listOf(AudioFormat.ENCODING_PCM_24BIT_PACKED, AudioFormat.ENCODING_PCM_16BIT)
        else listOf(AudioFormat.ENCODING_PCM_16BIT)

        for (enc in encs) {
            val bps = if (enc == AudioFormat.ENCODING_PCM_16BIT) 2 else 3
            val min = AudioRecord.getMinBufferSize(RATE, mask, enc)
            if (min <= 0) continue
            val size = maxOf(min * 4, RATE * channels * bps / 5)
            for ((src, name) in sources) {
                val r = runCatching {
                    AudioRecord.Builder()
                        .setAudioSource(src)
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(enc)
                                .setSampleRate(RATE)
                                .setChannelMask(mask)
                                .build()
                        )
                        .setBufferSizeInBytes(size)
                        .build()
                }.getOrNull() ?: continue
                if (r.state == AudioRecord.STATE_INITIALIZED) return Opened(r, bps, name)
                r.release()
            }
        }
        return null
    }

    // ---------- kayıt döngüsü ----------
    private fun record(channels: Int, bits: Int, raw: Boolean, export: Boolean) {
        var ar: AudioRecord? = null
        var writer: WavWriter? = null
        try {
            val o = open(channels, bits, raw)
            if (o == null) {
                RecorderState.error.value = "Mikrofon başlatılamadı. Başka bir uygulama kullanıyor olabilir."
                return
            }
            ar = o.ar
            val bps = o.bytesPerSample
            val frame = channels * bps
            val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
            writer = WavWriter(File(Recordings.dir(this), "Kayit_$stamp.wav"), RATE, channels, bps * 8)

            RecorderState.formatInfo.value =
                "48 kHz • ${bps * 8}-bit • ${if (channels == 2) "Stereo" else "Mono"} • ${o.sourceName}"

            val chunk = (RATE / 20) * frame          // 50 ms
            val bb = ByteBuffer.allocateDirect(chunk)
            val buf = ByteArray(chunk)
            val levels = ArrayList<Float>()
            var lastClip = 0L

            ar.startRecording()
            while (running) {
                bb.clear()
                val n = ar.read(bb, chunk)
                if (n < 0) {
                    RecorderState.error.value = "Mikrofon okunamadı (kod $n)"
                    break
                }
                if (n == 0 || paused) continue
                bb.rewind()
                bb.get(buf, 0, n)
                writer.write(buf, n)

                val peak = peak(buf, n, bps)
                val now = SystemClock.elapsedRealtime()
                if (peak >= 0.99f) lastClip = now
                val db = 20f * log10(maxOf(peak, 1e-5f))
                levels.add(((db + 60f) / 60f).coerceIn(0f, 1f))
                if (levels.size > 56) levels.removeAt(0)

                RecorderState.levels.value = levels.toList()
                RecorderState.elapsedMs.value = writer.dataBytes * 1000L / (frame.toLong() * RATE)
                RecorderState.clip.value = lastClip != 0L && now - lastClip < 1500
            }
        } catch (t: Throwable) {
            RecorderState.error.value = "Kayıt hatası: ${t.message}"
        } finally {
            runCatching { ar?.stop() }
            runCatching { ar?.release() }
            writer?.close()
            val f = writer?.file
            if (f != null && f.exists()) {
                if (writer.dataBytes == 0L) {
                    f.delete()
                } else {
                    if (export) Recordings.exportToMusic(applicationContext, f)
                    RecorderState.lastSaved.value = f.name
                }
            }
            RecorderState.status.value = Status.IDLE
            RecorderState.levels.value = emptyList()
            RecorderState.clip.value = false
            running = false
            paused = false
            wakeLock?.let { if (it.isHeld) it.release() }
            Handler(Looper.getMainLooper()).post {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun peak(buf: ByteArray, n: Int, bps: Int): Float {
        var max = 0
        var i = 0
        val step = bps * 4
        while (i + bps <= n) {
            val v = if (bps == 2) {
                (buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)
            } else {
                (buf[i + 2].toInt() shl 16) or ((buf[i + 1].toInt() and 0xFF) shl 8) or (buf[i].toInt() and 0xFF)
            }
            val a = abs(v)
            if (a > max) max = a
            i += step
        }
        val full = if (bps == 2) 32768f else 8388608f
        return (max / full).coerceIn(0f, 1f)
    }
}
