package com.oguzhn.seskaydedici

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------- Simgeler ----------------
private fun vec(name: String, path: String): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f)
        .addPath(addPathNodes(path), fill = SolidColor(Color.Black))
        .build()

val MicIcon = vec(
    "mic",
    "M12,14c1.66,0 2.99,-1.34 2.99,-3L15,5c0,-1.66 -1.34,-3 -3,-3S9,3.34 9,5v6c0,1.66 1.34,3 3,3zM17.3,11c0,3 -2.54,5.1 -5.3,5.1S6.7,14 6.7,11L5,11c0,3.41 2.72,6.23 6,6.72L11,21h2v-3.28c3.28,-0.48 6,-3.3 6,-6.72h-1.7z"
)
val PauseIcon = vec("pause", "M6,19h4V5H6v14zM14,5v14h4V5h-4z")
val ListIcon = vec("list", "M3,13h2v-2H3v2zM3,17h2v-2H3v2zM3,9h2V7H3v2zM7,13h14v-2H7v2zM7,17h14v-2H7v2zM7,7v2h14V7H7z")

// ---------------- Ayarlar ----------------
class AppSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var theme by mutableIntStateOf(sp.getInt("theme", 0))        // 0 sistem, 1 açık, 2 koyu
        private set
    var dynamic by mutableStateOf(sp.getBoolean("dynamic", false))
        private set
    var channels by mutableIntStateOf(sp.getInt("channels", 1))  // 1 mono, 2 stereo
        private set
    var bits by mutableIntStateOf(sp.getInt("bits", 16))          // 16 / 24
        private set
    var source by mutableIntStateOf(sp.getInt("source", 0))      // 0 ham, 1 standart
        private set
    var export by mutableStateOf(sp.getBoolean("export", true))
        private set
    var keepOn by mutableStateOf(sp.getBoolean("keepOn", false))
        private set

    fun updateTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun updateDynamic(v: Boolean) { dynamic = v; sp.edit().putBoolean("dynamic", v).apply() }
    fun updateChannels(v: Int) { channels = v; sp.edit().putInt("channels", v).apply() }
    fun updateBits(v: Int) { bits = v; sp.edit().putInt("bits", v).apply() }
    fun updateSource(v: Int) { source = v; sp.edit().putInt("source", v).apply() }
    fun updateExport(v: Boolean) { export = v; sp.edit().putBoolean("export", v).apply() }
    fun updateKeepOn(v: Boolean) { keepOn = v; sp.edit().putBoolean("keepOn", v).apply() }
}

// ---------------- Oynatıcı ----------------
class PlayerController {
    private var mp: MediaPlayer? = null
    var playingPath by mutableStateOf<String?>(null)
    var isPlaying by mutableStateOf(false)
    var positionMs by mutableIntStateOf(0)
    var durationMs by mutableIntStateOf(0)

    fun toggle(f: File): Boolean {
        val cur = mp
        if (cur != null && playingPath == f.path) {
            if (cur.isPlaying) { cur.pause(); isPlaying = false } else { cur.start(); isPlaying = true }
            return true
        }
        stop()
        return runCatching {
            val m = MediaPlayer()
            m.setDataSource(f.path)
            m.setOnCompletionListener {
                isPlaying = false
                positionMs = 0
                runCatching { it.seekTo(0) }
            }
            m.prepare()
            durationMs = m.duration
            positionMs = 0
            m.start()
            mp = m
            playingPath = f.path
            isPlaying = true
        }.onFailure { stop() }.isSuccess
    }

    fun seek(ms: Int) { mp?.seekTo(ms); positionMs = ms }

    fun tick() { val m = mp; if (m != null && isPlaying) positionMs = m.currentPosition }

    fun stop() {
        runCatching { mp?.release() }
        mp = null
        playingPath = null
        isPlaying = false
        positionMs = 0
        durationMs = 0
    }
}

// ---------------- Activity ----------------
class MainActivity : ComponentActivity() {
    private val player = PlayerController()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val settings = AppSettings(applicationContext)
        setContent { SesTheme(settings) { Root(settings, player) } }
    }

    override fun onDestroy() {
        player.stop()
        super.onDestroy()
    }
}

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFFF6B6B), onPrimary = Color(0xFF3A0707),
    secondary = Color(0xFF9DB4FF),
    background = Color(0xFF0E1014), onBackground = Color(0xFFE8EAEE),
    surface = Color(0xFF0E1014), onSurface = Color(0xFFE8EAEE),
    surfaceContainer = Color(0xFF181C22), surfaceContainerHighest = Color(0xFF2A2F38),
    onSurfaceVariant = Color(0xFFA9AFBA), error = Color(0xFFFF5252)
)
private val LightScheme = lightColorScheme(
    primary = Color(0xFFE5393B), onPrimary = Color.White,
    background = Color(0xFFFBF8F8), surface = Color(0xFFFBF8F8),
    surfaceContainer = Color(0xFFF1ECEC), surfaceContainerHighest = Color(0xFFE3DCDC)
)

@Composable
fun SesTheme(s: AppSettings, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = when (s.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val scheme = when {
        s.dynamic && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> DarkScheme
        else -> LightScheme
    }
    val activity = ctx as? ComponentActivity
    SideEffect {
        val bars = if (dark) SystemBarStyle.dark(AColor.TRANSPARENT)
        else SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT)
        activity?.enableEdgeToEdge(statusBarStyle = bars, navigationBarStyle = bars)
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

fun startRecording(ctx: Context) {
    ContextCompat.startForegroundService(
        ctx, Intent(ctx, RecorderService::class.java).setAction(RecorderService.ACTION_START)
    )
}

fun sendAction(ctx: Context, action: String) {
    ctx.startService(Intent(ctx, RecorderService::class.java).setAction(action))
}

@Composable
fun Root(settings: AppSettings, player: PlayerController) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }
    val saved by RecorderState.lastSaved.collectAsState()
    val error by RecorderState.error.collectAsState()
    val status by RecorderState.status.collectAsState()
    val view = LocalView.current

    SideEffect { view.keepScreenOn = status != Status.IDLE && settings.keepOn }

    LaunchedEffect(saved) {
        saved?.let {
            snackbar.showSnackbar("Kaydedildi: $it")
            RecorderState.lastSaved.value = null
        }
    }
    LaunchedEffect(error) {
        error?.let {
            snackbar.showSnackbar(it)
            RecorderState.error.value = null
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(MicIcon, null) }, label = { Text("Kayıt") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(ListIcon, null) }, label = { Text("Kayıtlar") }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Filled.Settings, null) }, label = { Text("Ayarlar") }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> RecordScreen(settings)
                1 -> RecordingsScreen(player)
                else -> SettingsScreen(settings)
            }
        }
    }
}

// ---------------- Kayıt ekranı ----------------
fun fmtTime(ms: Long): String {
    val t = ms / 100
    val tenth = t % 10
    val s = (t / 10) % 60
    val m = (t / 600) % 60
    val h = t / 36000
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d.%d", m, s, tenth)
}

fun fmtShort(ms: Int): String {
    val s = ms / 1000
    return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
}

@Composable
fun RecordScreen(settings: AppSettings) {
    val ctx = LocalContext.current
    val status by RecorderState.status.collectAsState()
    val elapsed by RecorderState.elapsedMs.collectAsState()
    val levels by RecorderState.levels.collectAsState()
    val clip by RecorderState.clip.collectAsState()
    val liveInfo by RecorderState.formatInfo.collectAsState()

    val recording = status == Status.RECORDING
    val active = status != Status.IDLE

    val plannedInfo = "48 kHz • ${settings.bits}-bit • " +
        (if (settings.channels == 2) "Stereo" else "Mono") + " • " +
        (if (settings.source == 0) "Ham" else "Standart")
    val info = if (active && liveInfo.isNotEmpty()) liveInfo else plannedInfo

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.RECORD_AUDIO] == true) startRecording(ctx)
        else Toast.makeText(ctx, "Kayıt için mikrofon izni gerekli", Toast.LENGTH_LONG).show()
    }

    fun onMain() {
        if (active) {
            sendAction(ctx, RecorderService.ACTION_STOP)
        } else {
            val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            if (granted) startRecording(ctx)
            else permLauncher.launch(
                if (Build.VERSION.SDK_INT >= 33)
                    arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
                else arrayOf(Manifest.permission.RECORD_AUDIO)
            )
        }
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AssistChip(onClick = {}, label = { Text(info) })

        Spacer(Modifier.weight(1f))

        Text(
            when (status) {
                Status.IDLE -> "Hazır"
                Status.RECORDING -> "Kayıt yapılıyor"
                Status.PAUSED -> "Duraklatıldı"
            },
            style = MaterialTheme.typography.titleMedium,
            color = if (recording) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            fmtTime(elapsed),
            fontSize = 56.sp,
            fontWeight = FontWeight.Light,
            fontFamily = FontFamily.Monospace
        )

        Spacer(Modifier.height(16.dp))
        LevelBars(levels, clip, Modifier.fillMaxWidth().height(110.dp))
        Text(
            if (clip) "Ses çok yüksek! Mikrofondan biraz uzaklaş." else " ",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error
        )

        Spacer(Modifier.weight(1f))

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            Box(Modifier.size(60.dp), contentAlignment = Alignment.Center) {
                if (active) {
                    FilledTonalIconButton(
                        onClick = {
                            sendAction(ctx, if (recording) RecorderService.ACTION_PAUSE else RecorderService.ACTION_RESUME)
                        },
                        modifier = Modifier.size(60.dp)
                    ) {
                        Icon(
                            if (recording) PauseIcon else Icons.Filled.PlayArrow,
                            if (recording) "Duraklat" else "Devam"
                        )
                    }
                }
            }
            RecordButton(recording = recording, active = active) { onMain() }
            Spacer(Modifier.size(60.dp))
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "İpucu: Telefonu ağzından 15–20 cm uzakta tut, sessiz bir ortam seç.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun LevelBars(levels: List<Float>, clip: Boolean, modifier: Modifier) {
    val on = if (clip) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
    val off = MaterialTheme.colorScheme.surfaceContainerHighest
    Canvas(modifier) {
        val n = 56
        val gap = size.width / n
        val barW = gap * 0.55f
        val mid = size.height / 2
        val minH = 6.dp.toPx()
        for (i in 0 until n) {
            val idx = levels.size - n + i
            val v = if (idx >= 0) levels[idx] else 0f
            val h = maxOf(minH, v * size.height)
            drawRoundRect(
                color = if (idx >= 0) on else off,
                topLeft = Offset(i * gap + (gap - barW) / 2, mid - h / 2),
                size = Size(barW, h),
                cornerRadius = CornerRadius(barW / 2)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordButton(recording: Boolean, active: Boolean, onClick: () -> Unit) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(150.dp)) {
        if (recording) {
            val t = rememberInfiniteTransition(label = "pulse")
            val s by t.animateFloat(
                initialValue = 1f, targetValue = 1.2f,
                animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
                label = "scale"
            )
            Box(
                Modifier.size(120.dp).scale(s)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f), CircleShape)
            )
        }
        Surface(
            onClick = onClick,
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primary,
            shadowElevation = 6.dp,
            modifier = Modifier.size(96.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                if (active) {
                    Box(
                        Modifier.size(30.dp)
                            .background(MaterialTheme.colorScheme.onPrimary, RoundedCornerShape(8.dp))
                    )
                } else {
                    Icon(MicIcon, "Kaydet", Modifier.size(44.dp), tint = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
    }
}

// ---------------- Kayıtlar ekranı ----------------
@Composable
fun RecordingsScreen(player: PlayerController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val saved by RecorderState.lastSaved.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    var recs by remember { mutableStateOf<List<Rec>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Rec?>(null) }
    val dateFmt = remember { SimpleDateFormat("d MMM yyyy • HH:mm", Locale("tr", "TR")) }

    LaunchedEffect(saved, tick) {
        recs = withContext(Dispatchers.IO) { Recordings.list(ctx) }
        loaded = true
    }
    LaunchedEffect(player.isPlaying) {
        while (player.isPlaying) {
            player.tick()
            delay(200)
        }
    }

    if (loaded && recs.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("Henüz kayıt yok", style = MaterialTheme.typography.bodyLarge)
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(recs, key = { it.file.name }) { r ->
                val current = player.playingPath == r.file.path
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FilledTonalIconButton(onClick = {
                                if (!player.toggle(r.file)) {
                                    Toast.makeText(ctx, "Bu kayıt çalınamadı", Toast.LENGTH_LONG).show()
                                }
                            }) {
                                Icon(
                                    if (current && player.isPlaying) PauseIcon else Icons.Filled.PlayArrow,
                                    "Oynat"
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    dateFmt.format(Date(r.modified)),
                                    style = MaterialTheme.typography.titleMedium, maxLines = 1
                                )
                                Text(
                                    fmtShort(r.durationMs.toInt()) + " • " + "%.1f MB".format(Locale.US, r.size / 1048576.0) +
                                        " • " + r.info,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                                )
                            }
                            IconButton(onClick = { Recordings.share(ctx, r.file) }) {
                                Icon(Icons.Filled.Share, "Paylaş")
                            }
                            IconButton(onClick = { toDelete = r }) {
                                Icon(Icons.Filled.Delete, "Sil")
                            }
                        }
                        if (current) {
                            Slider(
                                value = player.positionMs.toFloat(),
                                onValueChange = { player.seek(it.toInt()) },
                                valueRange = 0f..maxOf(1f, player.durationMs.toFloat())
                            )
                            Row(Modifier.fillMaxWidth()) {
                                Text(fmtShort(player.positionMs), style = MaterialTheme.typography.labelSmall)
                                Spacer(Modifier.weight(1f))
                                Text(fmtShort(player.durationMs), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { r ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Kayıt silinsin mi?") },
            text = { Text("Bu işlem geri alınamaz. Müzik klasöründeki kopya da silinmeye çalışılır.") },
            confirmButton = {
                TextButton(onClick = {
                    if (player.playingPath == r.file.path) player.stop()
                    toDelete = null
                    scope.launch {
                        withContext(Dispatchers.IO) { Recordings.delete(ctx, r.file) }
                        tick++
                    }
                }) { Text("Sil") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Vazgeç") } }
        )
    }
}

// ---------------- Ayarlar ekranı ----------------
@Composable
fun SettingsScreen(s: AppSettings) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SectionCard("Kayıt kalitesi") {
            Text("Kaynak", style = MaterialTheme.typography.titleMedium)
            ChipRow(listOf("Ham", "Standart"), s.source) { s.updateSource(it) }
            Text("Bit derinliği", style = MaterialTheme.typography.titleMedium)
            ChipRow(listOf("16-bit", "24-bit"), if (s.bits == 24) 1 else 0) { s.updateBits(if (it == 1) 24 else 16) }
            Text("Kanal", style = MaterialTheme.typography.titleMedium)
            ChipRow(listOf("Mono", "Stereo"), s.channels - 1) { s.updateChannels(it + 1) }
            Text(
                "Kayıtlar 48 kHz sıkıştırmasız WAV olarak alınır. Ham kaynakta otomatik ses yükseltme, " +
                    "gürültü bastırma ve eko giderme uygulanmaz. 24-bit bazı oynatıcılarda açılmayabilir; " +
                    "telefon desteklemezse 16-bit'e geçilir.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        SectionCard("Saklama") {
            SwitchRow(
                "Müzik klasörüne de kaydet",
                "Müzik/Ses Kaydedici içine kopya alınır; uygulamayı silsen bile kalır",
                s.export
            ) { s.updateExport(it) }
            SwitchRow("Kayıtta ekranı açık tut", "Kayıt sürerken ekran kapanmaz", s.keepOn) { s.updateKeepOn(it) }
        }
        SectionCard("Görünüm") {
            Text("Tema", style = MaterialTheme.typography.titleMedium)
            ChipRow(listOf("Sistem", "Açık", "Koyu"), s.theme) { s.updateTheme(it) }
            if (Build.VERSION.SDK_INT >= 31) {
                SwitchRow("Dinamik renk", "Renkler duvar kağıdına uyar", s.dynamic) { s.updateDynamic(it) }
            }
        }
    }
}

@Composable
fun ChipRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, name ->
            FilterChip(selected = selected == i, onClick = { onSelect(i) }, label = { Text(name) })
        }
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
