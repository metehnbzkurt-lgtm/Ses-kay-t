package com.oguzhn.seskaydedici

import kotlinx.coroutines.flow.MutableStateFlow

enum class Status { IDLE, RECORDING, PAUSED }

/** Servis ile arayüz arasındaki ortak durum. */
object RecorderState {
    val status = MutableStateFlow(Status.IDLE)
    val elapsedMs = MutableStateFlow(0L)
    val levels = MutableStateFlow<List<Float>>(emptyList())
    val clip = MutableStateFlow(false)
    val lastSaved = MutableStateFlow<String?>(null)
    val error = MutableStateFlow<String?>(null)
    val formatInfo = MutableStateFlow("")
}
