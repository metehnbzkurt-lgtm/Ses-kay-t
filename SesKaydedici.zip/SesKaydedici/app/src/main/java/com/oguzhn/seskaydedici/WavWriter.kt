package com.oguzhn.seskaydedici

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Sıkıştırmasız PCM WAV yazar. Başlık düzenli aralıklarla güncellenir;
 * uygulama beklenmedik kapansa bile dosya oynatılabilir kalır.
 */
class WavWriter(
    val file: File,
    private val rate: Int,
    private val channels: Int,
    private val bits: Int
) {
    private val raf = RandomAccessFile(file, "rw")
    var dataBytes = 0L
        private set
    private var sinceHeader = 0

    init {
        raf.setLength(0)
        raf.write(header(0))
    }

    fun write(buf: ByteArray, n: Int) {
        raf.write(buf, 0, n)
        dataBytes += n
        if (++sinceHeader >= 100) {
            sinceHeader = 0
            patch()
        }
    }

    private fun patch() {
        val pos = raf.filePointer
        raf.seek(0)
        raf.write(header(dataBytes))
        raf.seek(pos)
    }

    fun close() {
        runCatching { patch(); raf.close() }
    }

    private fun header(data: Long): ByteArray {
        val byteRate = rate * channels * bits / 8
        val blockAlign = channels * bits / 8
        val bb = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt((36 + data).toInt())
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1)
        bb.putShort(channels.toShort())
        bb.putInt(rate)
        bb.putInt(byteRate)
        bb.putShort(blockAlign.toShort())
        bb.putShort(bits.toShort())
        bb.put("data".toByteArray())
        bb.putInt(data.toInt())
        return bb.array()
    }
}
