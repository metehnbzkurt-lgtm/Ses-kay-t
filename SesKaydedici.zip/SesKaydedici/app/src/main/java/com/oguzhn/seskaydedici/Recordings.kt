package com.oguzhn.seskaydedici

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class Rec(
    val file: File,
    val durationMs: Long,
    val size: Long,
    val info: String,
    val modified: Long
)

object Recordings {
    private const val REL_PATH = "Music/Ses Kaydedici"

    fun dir(ctx: Context): File =
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "Kayitlar").apply { mkdirs() }

    fun list(ctx: Context): List<Rec> =
        (dir(ctx).listFiles { f -> f.extension.equals("wav", true) } ?: emptyArray())
            .mapNotNull { runCatching { read(it) }.getOrNull() }
            .sortedByDescending { it.modified }

    private fun read(f: File): Rec {
        val h = ByteArray(44)
        RandomAccessFile(f, "r").use { it.readFully(h) }
        val bb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        val ch = bb.getShort(22).toInt()
        val rate = bb.getInt(24)
        val bits = bb.getShort(34).toInt()
        val byteRate = rate.toLong() * ch * bits / 8
        val dur = if (byteRate > 0) (f.length() - 44) * 1000 / byteRate else 0L
        val info = "${rate / 1000} kHz • $bits-bit • ${if (ch == 2) "Stereo" else "Mono"}"
        return Rec(f, dur, f.length(), info, f.lastModified())
    }

    /** Müzik/Ses Kaydedici klasörüne kopyalar (uygulama silinse bile kalır). */
    fun exportToMusic(ctx: Context, f: File): Boolean = runCatching {
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, f.name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
            put(MediaStore.Audio.Media.RELATIVE_PATH, REL_PATH)
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val r = ctx.contentResolver
        val uri = r.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: error("insert")
        r.openOutputStream(uri)!!.use { out -> f.inputStream().use { it.copyTo(out) } }
        values.clear()
        values.put(MediaStore.Audio.Media.IS_PENDING, 0)
        r.update(uri, values, null, null)
        true
    }.getOrDefault(false)

    fun delete(ctx: Context, f: File) {
        f.delete()
        runCatching {
            ctx.contentResolver.delete(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                "${MediaStore.Audio.Media.DISPLAY_NAME}=? AND ${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?",
                arrayOf(f.name, "$REL_PATH%")
            )
        }
    }

    fun share(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        val i = Intent(Intent.ACTION_SEND)
            .setType("audio/wav")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Kaydı paylaş"))
    }
}
